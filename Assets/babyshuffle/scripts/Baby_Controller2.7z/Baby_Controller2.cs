﻿using UnityEngine;
using System.Collections;

public class Baby_Controller2 : MonoBehaviour
{
		public float movespeed;
		private Vector3 moveDirection;
		public float turnSpeed;
		private Vector3 tPos;
		public float Right_Clamp = 4;
		public AudioClip babyContactSound;
	
		// Use this for initialization
		void Start ()
		{
				moveDirection = Vector3.right;
		}
	
		// Update is called once per frame
		void Update ()
		{
				Vector3 currentPosition = transform.position;

				if (Input.GetButton ("Fire1")) {

						Vector3 pos = Camera.main.ScreenToWorldPoint (Input.mousePosition);
						RaycastHit2D hit = Physics2D.Raycast (pos, Vector2.zero);
						if (hit != null && hit.collider != null) {
								Debug.Log ("I'm hitting " + hit.collider.name);
								//Destroy (hit.collider.gameObject);
								thescore.myscore += 1;
								audio.PlayOneShot (babyContactSound);
								Destroy (hit.collider.gameObject, 0.47f);// Destroy the object -after- the sound played
						}				
				}
		
				Vector3 target = moveDirection * movespeed + currentPosition;
				transform.position = Vector3.Lerp (currentPosition, target, Time.deltaTime);
		
				if (rigidbody2D.position.x >= 6) {
						Debug.Log ("clamp right");
						DestroyObject (this.gameObject);	
						thescore.mysleepscore += 1;	
				}
				//float targetAngle = Mathf.Atan2 (moveDirection.y, moveDirection.x) * Mathf.Rad2Deg;
				//transform.rotation = Quaternion.Slerp (transform.rotation, Quaternion.Euler (0, 0, targetAngle), turnSpeed * Time.deltaTime);				
		}
}
